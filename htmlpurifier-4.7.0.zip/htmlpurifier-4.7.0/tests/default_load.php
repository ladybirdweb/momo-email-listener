<?php
class default_load { }
echo "Default loaded\n";
